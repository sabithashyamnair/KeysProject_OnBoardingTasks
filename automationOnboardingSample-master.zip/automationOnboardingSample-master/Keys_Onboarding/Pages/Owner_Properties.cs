﻿using Keys_Onboarding.Global;
using Keys_Onboarding.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using RelevantCodes.ExtentReports;
using System;
using static Keys_Onboarding.Global.CommonMethods;

namespace Keys_Onboarding
{
    public class Owner_Properties
    {
        public Owner_Properties()
        {
            PageFactory.InitElements(Global.Driver.driver, this);
        }

        #region WebElements Definition

        [FindsBy(How = How.XPath, Using = "//*[contains(@class,'introjs-button introjs-skipbutton')]")]
        private IWebElement QuickButton { set; get; }


        //Define Owners tab
        //[FindsBy(How =How.XPath,Using = "/html/body/nav/div/ul/li[2]/a")]

        [FindsBy(How = How.XPath, Using = "/html/body/div/div/div[2]/div[1]/i")]
        private IWebElement Ownertab { set; get; }


        //public SelectElement Ownertab => new SelectElement(Driver.driver.FindElement(By.XPath("//div[2]//div//@class")));
        //public IWebElement Ownertab { set; get; }

        //Define Properties page
        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[2]/div[1]/div/a[1]")]
        // [FindsBy(How = How.XPath, Using = "//a[@class= 'item item-link ']")]
        private IWebElement PropertiesPage { set; get; }

        // Define Add new property Button
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']/div/div[1]/div/div[2]/div/div[2]/a[2]")]
        private IWebElement AddNewPropertyBtn { set; get; }

        //Define search bar        
        [FindsBy(How = How.XPath, Using = "//*[@id='SearchBox']")]
        private IWebElement SearchBar { set; get; }

        //Define search button
        [FindsBy(How = How.XPath, Using = "//*[@id='search-wrap']/form/div/i")]
        private IWebElement SearchButton { set; get; }

        //Define List A Rental Page
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']//div[1]//div[2]//div[2]/a[1]/i")]
        private IWebElement ListARentalBtn { set; get; }

        //Define icon on Property for Delete option
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']//div[1]//div[3]/div[1]/div[1]/div//div[2]/div[1]/div[3]//i")]
        private IWebElement IconforDel { set; get; }

        //Define Delete option from property icon
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']//div[1]//div[3]/div[1]/div[1]/div//div[2]/div[1]/div[3]//div[5]")]
        private IWebElement DeleteProp { set; get; }

        //*[@id='main-content']//div[1]//div[3]/div[1]/div[1]/div//div[2]/div[1]/div[3]//div[5]

        #endregion

        public void Common_methods()
        {
            // Global.Driver.wait(15);
            QuickButton.Click();

            //Click on the Owners tab
            Driver.wait(60);
            Global.Driver.wait(60);

            Console.WriteLine(Ownertab.Displayed);
            Console.WriteLine(Ownertab.Enabled);
            //Console.WriteLine(Ownertab.Selected);


            //Ownertab.SelectByText("Properties");
            //((IJavaScriptExecutor)Driver.driver).ExecuteScript("arguments[0].hidden = false;", Ownertab);
            // ((IJavaScriptExecutor)Driver.driver).ExecuteScript("arguments[0].hidden = false;", Ownertab);
            ((IJavaScriptExecutor)Driver.driver).ExecuteScript("arguments[0].click();", Ownertab);
            // Driver.driver.SwitchTo().DefaultContent();
            // Ownertab.Click();
            Driver.wait(60);
            Global.Driver.wait(60);

            // ((IJavaScriptExecutor)Driver.driver).ExecuteScript("arguments[0].hidden = true;", Ownertab);

            //Console.WriteLine(Ownertab.Selected);
            //Console.WriteLine(Ownertab.Selected);
            //Global.Driver.wait(60);
            //Select properties page
            ((IJavaScriptExecutor)Driver.driver).ExecuteScript("arguments[0].click();", PropertiesPage);

            //PropertiesPage.Click();
        }

        internal void AddNewProperty()
        {
            try
            {
                //Calling the common methods
                Common_methods();
                Driver.wait(15);

                //Click on Add New Property Button
                AddNewPropertyBtn.Click();

                Driver.wait(15);
                //Calling Add Property details method
                AddProperty_Owner obj = new AddProperty_Owner();
                obj.AddPropertyDetails();
                Driver.wait(15);

                //Calling Add Finance Details method
                obj.AddFinanceDetails();
                Driver.wait(15);

                //Calling Add Tenant Details method
                obj.AddTenantDetails();
                Driver.wait(15);

            }

            catch (Exception e)
            {
                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Test Failed, Add New Property Unsuccessfull", e.Message);
            }
        }

        internal void SearchAProperty()
        {
            try
            {
                //Calling the common methods
                Common_methods();
                Driver.wait(15);

                //Enter the value in the search bar
                SearchBar.SendKeys("Woodards");
                Global.Driver.wait(15);

                //Click on the search button
                SearchButton.Click();
                Driver.wait(5);

                string ExpectedValue = "Woodards";
                string ActualValue = Global.Driver.driver.FindElement(By.XPath("//*[@id='mainPage']/div[4]/div[1]/div/div/div[2]/div[2]/div[1]/div[1]/div[1]")).Text;

                //Assert.AreEqual(ExpectedValue, ActualValue);
                if (ExpectedValue == ActualValue)

                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Pass, "Test Passed, Search successfull");

                else
                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Test Failed, Search Unsuccessfull");

            }

            catch (Exception e)
            {
                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Test Failed, Search Unsuccessfull", e.Message);
            }
        }


        internal void ListRentalProperty()
        {
            try
            {
                //Calling the common methods
                Common_methods();
                Driver.wait(15);
                ListARentalBtn.Click();

                Driver.wait(15);
                ListARental_Owner obj = new ListARental_Owner();
                obj.ListARental();

            }
            catch (Exception e)
            {
                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Test Failed, List a rental Unsuccessfull", e.Message);
            }

        }

        internal void DeleteAProperty()
        {
            try
            {
                //Calling the common methods
                // Common_methods();
                SearchAProperty();
                Driver.wait(1000);
                IconforDel.Click();
                Driver.wait(1000);
                //DeleteProp.Click();


                ((IJavaScriptExecutor)Driver.driver).ExecuteScript("arguments[0].click();", DeleteProp);
                // Driver.driver.SwitchTo().DefaultContent();
                Driver.wait(60);
                Global.Driver.wait(60);
                Driver.wait(60);

                DeleteProperty_Owner obj = new DeleteProperty_Owner();
                obj.DeleteProperty();

            }
            catch (Exception e)
            {
                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Test Failed, Delete Property Unsuccessfull", e.Message);
            }
        }
    }
}
