﻿using System;
namespace Keys_Onboarding.Pages
{
    public class AddNewProperty
    {
        public AddNewProperty()
        {
        }
    }
}
