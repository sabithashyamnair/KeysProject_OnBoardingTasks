﻿using Keys_Onboarding.Global;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using RelevantCodes.ExtentReports;
using System;
using static Keys_Onboarding.Global.CommonMethods;


namespace Keys_Onboarding.Pages
{
    public class DeleteProperty_Owner
    {
        public DeleteProperty_Owner()
        {
            PageFactory.InitElements(Global.Driver.driver, this);
        }

        #region WebElements Definition

        //Define confirm Button upon clicking delete
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']//div[4]//div[2]/div[7]/button[1]")]
        private IWebElement ConfirmBtn { set; get; }

        #endregion

        public void DeleteProperty()
        {
            Driver.wait(15);
            ConfirmBtn.Click();

        }
    }
}
