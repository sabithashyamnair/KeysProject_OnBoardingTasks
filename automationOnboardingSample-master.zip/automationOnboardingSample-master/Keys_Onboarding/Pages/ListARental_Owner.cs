﻿using Keys_Onboarding.Global;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using RelevantCodes.ExtentReports;
using System;
using System.Collections.Generic;
using System.Linq;
using static Keys_Onboarding.Global.CommonMethods;

namespace Keys_Onboarding
{
    public class ListARental_Owner
    {
        public ListARental_Owner()
        {
            PageFactory.InitElements(Global.Driver.driver, this);
        }


        #region WebElements Definition

   /*     //Define List A Rental Page
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']//div[1]//div[2]//div[2]/a[1]/i")]
        private IWebElement ListARentalBtn { set; get; }  */

        //Define Select property
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']/div/form/fieldset/div[2]/div/input[2]")]
        private IWebElement SelectProperty { set; get; }
        //public SelectElement SelectProperty => new SelectElement(Driver.driver.FindElement(By.XPath("//*[@id='main-content']/div/form/fieldset/div[2]/div/input[2]")));

        //Define Title
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']/div/form/fieldset/div[3]/div[1]/input[1]")]
        private IWebElement Title { set; get; }

        //Define Moving Cost
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']/div/form/fieldset/div[3]/div[1]/input[2]")]
        private IWebElement MovingCost { set; get; }

        //Define Description
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']/div/form/fieldset/div[3]/div[2]/textarea")]
        private IWebElement Description { set; get; }

        //Define Target Rent 
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']/div/form/fieldset/div[4]/div[1]/input")]
        private IWebElement TargetRent  { set; get; }

        //Define Available Date  
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']/div/form/fieldset/div[5]/div[1]/input")]
        private IWebElement AvailableDate { set; get; }

        //Define Occupants Count
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']/div/form/fieldset/div[6]/div[1]/input")]
        private IWebElement OccupantsCount { set; get; }

        //Define Save Button
        [FindsBy(How = How.XPath, Using = "//*[@id='main-content']/div/form/fieldset/div[8]/div/button[1]")]
        private IWebElement SaveBtn { set; get; }

        #endregion

        private IWebElement FindElement(By by)
        {
            throw new NotImplementedException();
        }

        public void ListARental()
        {
          /*  Driver.wait(15);
            ListARentalBtn.Click();*/
            Driver.wait(15);
            SelectProperty.SendKeys("2 Beverley, Glen Huntly, Melbourne, 3163");
           

            /* Console.WriteLine("Before list");
             //SelectProperty.SelectByIndex(2);
             //Choose Select Property Type from Dropdown list
             IList<IWebElement> SelectProperty = Driver.driver.FindElements(By.XPath("//*[@id='main-content']/div/form/fieldset/div[2]/div/div[2]/div[1]"));
             Console.WriteLine("Before count");
             int listcount = SelectProperty.Count();
             Console.WriteLine(SelectProperty.Count());
             for (int i = 0; i < listcount; i++)
             {
                 Console.WriteLine(SelectProperty[i].Text);
                 if (SelectProperty[i].Text == "2 Beverley, Glen Huntly, Melbourne, 3163")
                 {
                     Console.WriteLine("inside if");
                     Driver.wait(100);
                     SelectProperty[i].Click();
                     Driver.wait(100);
                 }
             } */

            Title.SendKeys("This Property is Out Listed for Rent");

            MovingCost.SendKeys("53000");

            Description.SendKeys("This is a spacious 2BHK House on rent");

            TargetRent.SendKeys("385");

            AvailableDate.Clear();
            Driver.wait(1000);

            AvailableDate.SendKeys("28/10/2018");

            OccupantsCount.SendKeys("3");

            SaveBtn.Click();

        }


       /* internal void ListRentalProperty()
        {
            try
            {
                //Calling the common methods
               // Common_methods();
                Driver.wait(15);
                ListARental();

            }
            catch (Exception e)
            {
                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Test Failed, List a rental Unsuccessfull", e.Message);
            }
        }*/
    }
}
