﻿using Keys_Onboarding.Global;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using RelevantCodes.ExtentReports;
using System;
using static Keys_Onboarding.Global.CommonMethods;


namespace Keys_Onboarding
{
    public class AddProperty_Owner
    {
        public AddProperty_Owner()
        {
            PageFactory.InitElements(Global.Driver.driver, this);
        }

        #region WebElements Definition

        /* [FindsBy(How = How.XPath, Using = "//*[contains(@class,'introjs-button introjs-skipbutton')]")]
           private IWebElement QuickButton { set; get; }


         //Define Owners tab
         //[FindsBy(How =How.XPath,Using = "/html/body/nav/div/ul/li[2]/a")]

         [FindsBy(How = How.XPath, Using = "/html/body/div/div/div[2]/div[1]/i")]
          private IWebElement Ownertab { set; get; }


         //public SelectElement Ownertab => new SelectElement(Driver.driver.FindElement(By.XPath("//div[2]//div//@class")));
         //public IWebElement Ownertab { set; get; }

         //Define Properties page
         [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[2]/div[1]/div/a[1]")]
        // [FindsBy(How = How.XPath, Using = "//a[@class= 'item item-link ']")]
         private IWebElement PropertiesPage { set; get; }
 */
        /*    //Define search bar        
             [FindsBy(How = How.XPath, Using = "//*[@id='SearchBox']")]
             private IWebElement SearchBar { set; get; }

             //Define search button

             [FindsBy(How = How.XPath, Using = "//*[@id='search-wrap']/form/div/i")]
             private IWebElement SearchButton { set; get; }
             */

        /*    //Define Add new property
            [FindsBy(How = How.XPath, Using = "//*[@id='main-content']/div/div[1]/div/div[2]/div/div[2]/a[2]")]
            private IWebElement AddNewPropertyBtn { set; get; }  */

        //Adding Property details
        //Define property name
        [FindsBy(How = How.XPath, Using = "//*[@id='property-details']//div[2]//div[1]//div[1]//input")]
        private IWebElement PropertyName { set; get; }


        //*[@id="property-details"]/div[2]/div[1]/div[1]/input

        //Define property type
        //[FindsBy(How = How.XPath, Using = "//*[@id='property - details']/div[2]/div[2]/div/i")]
        // private IWebElement PropertyType { set; get; }


        //Define search address
        [FindsBy(How = How.XPath, Using = "//*[@id='autocomplete']")]
        private IWebElement SearchAddress { set; get; }

        //Define Street number
        [FindsBy(How = How.XPath, Using = "//*[@class='six wide field']//div//*[@id='street_number']")]
        private IWebElement StreetNumber { set; get; }

        //Define Street
        [FindsBy(How = How.XPath, Using = "//*[@class='ten wide field']//*[@id='route']")]
        private IWebElement Street { set; get; }

        //Define City
        [FindsBy(How = How.XPath, Using = "//*[@class='three fields']//*[@id='street_number']")]
        private IWebElement City { set; get; }


        //Define post code
        [FindsBy(How = How.XPath, Using = "//*[@id='property-details']/div[3]//div/div[3]//div[3]//input")]
        private IWebElement PostCode { set; get; }

        //Define  Region
        [FindsBy(How = How.XPath, Using = "//*[@id='region']")]
        private IWebElement Region { set; get; }

        //Define  description
        [FindsBy(How = How.XPath, Using = "//*[@id='property-details']/div[3]/div[2]/div[1]/textarea")]
        private IWebElement Description { set; get; }

        //*[@id="property-details"]/div[3]/div[2]/div[1]/textarea

        //Define  target rent
        [FindsBy(How = How.XPath, Using = "//*[@id='property-details']/div[4]/div/div[1]/div[1]/input")]
        private IWebElement TargetRent { set; get; }


        //Define  Bedrooms
        [FindsBy(How = How.XPath, Using = "//*[@id='property-details']/div[6]/div[1]/div[1]/input")]
        private IWebElement Bedrooms { set; get; }


        //Define  Bathrooms
        [FindsBy(How = How.XPath, Using = "//*[@id='property-details']/div[6]/div[2]/div[1]/input")]
        private IWebElement Bathrooms { set; get; }


        //Define  car parks
        [FindsBy(How = How.XPath, Using = "//*[@id='property-details']/div[7]/div[1]/div[1]/input")]
        private IWebElement CarParks { set; get; }


        //Define  year built
        [FindsBy(How = How.XPath, Using = "//*[@id='property-details']/div[7]/div[2]/div[1]/input")]
        private IWebElement YearBuilt { set; get; }

        //Define choose files
        // [FindsBy(How = How.XPath, Using = "//*[@id='file - upload']")]
        // private IWebElement ChooseFiles { set; get; }

        //Define next               
        [FindsBy(How = How.XPath, Using = "//*[@id='property-details']/div[10]/div/button[1]")]
        private IWebElement NextProp { set; get; }

        //Add Finance Details
        //Define Purchase price
        [FindsBy(How = How.XPath, Using = "//*[@id='financeSection']/div[1]/div[1]/div[1]/input")]
        private IWebElement PurchasePrice { set; get; }

        //Define Mortgage
        [FindsBy(How = How.XPath, Using = "//*[@id='financeSection']/div[1]/div[2]/div[1]/input")]
        private IWebElement Mortgage { set; get; }

        //Define Home Value
        [FindsBy(How = How.XPath, Using = "//*[@id='financeSection']/div[1]/div[3]/div[1]/input")]
        private IWebElement HomeValue { set; get; }

        //Define Home Value Type
        // [FindsBy(How = How.XPath, Using = "//*[@id='financeSection']/div[1]/div[1]/div[1]/input")]
        // private IWebElement ValueType { set; get; }


        //Define Add repayment
        [FindsBy(How = How.XPath, Using = "//*[@id='financeSection']/div[4]/div/a/i")]
        private IWebElement AddRepayment { set; get; }

        //*[@id="financeSection"]/div[4]/div/a

        //Define Amount
        [FindsBy(How = How.XPath, Using = "//*[@id='financeSection']/div[3]/div/div[1]/div[1]/input")]
        private IWebElement RepAmount { set; get; }

        //Define Frequency
        //[FindsBy(How = How.XPath, Using = "//*[@id='financeSection']/div[4]/div/a")]
        // private IWebElement RepFrequency { set; get; }

        //Define start Date
        [FindsBy(How = How.XPath, Using = "//*[@id='payment-start-date']")]
        private IWebElement RepStartDate { set; get; }

        //Define End Date
        // [FindsBy(How = How.XPath, Using = "//*[@id='financeSection']/div[4]/div/a")]
        // private IWebElement RepEndDate { set; get; }


        /*   //Define Add expense
           [FindsBy(How = How.XPath, Using = "//*[@id='financeSection']/div[7]/div/a/i")]
           private IWebElement AddExpense { set; get; }

           //*[@id="financeSection"]/div[7]/div/a/i
           //*[@id="financeSection"]/div[7]/div/a/i

           //Define  expense amount
           [FindsBy(How = How.XPath, Using = "//*[@id='financeSection']//*[@placeholder='Expenses']")]
           private IWebElement ExpAmount { set; get; }

           //Define expense Description
           [FindsBy(How = How.XPath, Using = "//*[@placeholder='Description']")]
           private IWebElement ExpDescription { set; get; }

           //Define Date
           [FindsBy(How = How.XPath, Using = "//*[@id='expense-date']")]
           private IWebElement ExpDate { set; get; } */

        //Define Next
        [FindsBy(How = How.XPath, Using = "//*[@id='financeSection']/div[8]/button[3]")]
        private IWebElement NextFin { set; get; }

        //Add Tenant Details
        //Define Tenant Email
        [FindsBy(How = How.XPath, Using = "//*[@id='email']")]
        private IWebElement TenantEmail { set; get; }

        //Define Is Main Tenant
        // [FindsBy(How = How.XPath, Using = "//*[@id='tenantSection']/div[1]/div[2]/div")]
        // private IWebElement IsMainTenant { set; get; }

        //Define First Name 
        [FindsBy(How = How.XPath, Using = "//*[@id='fname']")]
        private IWebElement TenFirstName { set; get; }

        //Define Last Name
        [FindsBy(How = How.XPath, Using = "//*[@id='lname']")]
        private IWebElement TenLastName { set; get; }

        //Define Start Date
        [FindsBy(How = How.XPath, Using = "//*[@id='sdate']")]
        private IWebElement TenStartDate { set; get; }

        //Define End Date
        [FindsBy(How = How.XPath, Using = "//*[@id='edate']")]
        private IWebElement TenEndDate { set; get; }

        //Define Rent Amount
        [FindsBy(How = How.XPath, Using = "//*[@id='ramount']")]
        private IWebElement TenRentAmount { set; get; }

        //Define Payment frequency
        //[FindsBy(How = How.XPath, Using = "//*[@id='tenantSection']/div[1]/div[8]/div")]
        // private IWebElement TenPaymentfrequency { set; get; }

        //Define Payment Start Date
        [FindsBy(How = How.XPath, Using = "//*[@id='psdate']")]
        private IWebElement TenPaymentStartDate { set; get; }

        //Define Payment Due Day
        //[FindsBy(How = How.XPath, Using = "//*[@id='tenantSection']/div[1]/div[10]/div")]
        // private IWebElement TenPaymentDueDay { set; get; }

        //Define Add New Liability
        [FindsBy(How = How.XPath, Using = "//*[@id='tenantSection']/div[4]/a/i")]
        private IWebElement AddNewLiability { set; get; }

        //Define Liability Name
        //[FindsBy(How = How.XPath, Using = "//*[@id='LiabilityDetail']/div/div[1]/div[1]/select")]
        // private IWebElement LiabilityName { set; get; }

        //Define Amount
        [FindsBy(How = How.XPath, Using = "//*[@id='LiabilityDetail']/div/div[1]/div[2]/div[1]/input")]
        private IWebElement LiabilityAmount { set; get; }

        //*[@id='LiabilityDetail']/div/div[1]/div[2]/div[1]/input
        //*[@id="LiabilityDetail"]/div/div[1]/div[2]/div[1]/input

        //Define Save
        [FindsBy(How = How.XPath, Using = "//*[@id='saveProperty']")]
        private IWebElement TenSave { set; get; }

        #endregion


        public void AddPropertyDetails()
        {
            /* //Click on Add New Property Button
             AddNewPropertyBtn.Click(); */

            Driver.wait(15);

            // Populating the data from Excel
            ExcelLib.PopulateInCollection(Base.ExcelPath, "PropertyDetailsPage");


            // Sending the PropertyName 
            PropertyName.SendKeys(ExcelLib.ReadData(2, "PropertyName"));

            // Sending the StreetNumber
            StreetNumber.SendKeys(ExcelLib.ReadData(2, "StreetNumber"));


            //Enter value in property type
            // PropertyType.SendKeys(""

            //Enter the value in Search Address
            // SearchAddress.SendKeys("unit 2 5, Kings st, Melbourne");
            // Driver.wait(5);

            //Enter the value in Street
            Street.SendKeys(ExcelLib.ReadData(2, "Street"));

            //Enter the value in City
            City.SendKeys(ExcelLib.ReadData(2, "City"));

            //Enter the value in Post code
            PostCode.SendKeys(ExcelLib.ReadData(2, "PostCode"));

            //Enter the value in Region
            Region.SendKeys(ExcelLib.ReadData(2, "Region"));

            //Enter the value in description
            Description.SendKeys(ExcelLib.ReadData(2, "Description"));

            //Enter the value in target rent
            TargetRent.SendKeys(ExcelLib.ReadData(2, "TargetRent"));

            //Enter the value in Bedrooms
            Bedrooms.SendKeys(ExcelLib.ReadData(2, "Bedrooms"));

            //Enter the value in Bathrooms
            Bathrooms.SendKeys(ExcelLib.ReadData(2, "Bathrooms"));

            //Enter the value in car parks
            CarParks.SendKeys(ExcelLib.ReadData(2, "CarParks"));

            Driver.wait(15);
            //Enter the value in year built
            YearBuilt.SendKeys(ExcelLib.ReadData(2, "YearBuilt"));
            Driver.wait(15);
            //Enter the value in choose files
            // ChooseFiles.SendKeys("unit 2 5, Kings st, Melbourne");
            //  Driver.wait(5);

            //clcik next button
            NextProp.Click();
            Driver.wait(5);

            string ExpectedValue = "Finance Details";
            string ActualValue = Global.Driver.driver.FindElement(By.XPath("//*[@id='financeSection']/h2")).Text;

            //Assert.AreEqual(ExpectedValue, ActualValue);
            if (ExpectedValue == ActualValue)

                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Pass, "Test Passed, Add Property Details successfull");

            else
                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Test Failed, Add Property Details Unsuccessfull");

        }

        public void AddFinanceDetails()

        {
            Driver.wait(15);

            // Populating the data from Excel
            ExcelLib.PopulateInCollection(Base.ExcelPath, "FinanceDetailsPage");
            Driver.wait(15);

            //Enter the value in the Purchase Price
            PurchasePrice.SendKeys(ExcelLib.ReadData(2, "PurchasePrice"));
            Driver.wait(15);

            //Enter the value Mortgage
            Mortgage.SendKeys(ExcelLib.ReadData(2, "Mortgage"));
            Driver.wait(15);

            //Enter the value in Home Value
            HomeValue.SendKeys(ExcelLib.ReadData(2, "HomeValue"));

            //Click Add Repayment
            //AddRepayment.Click();
            //Driver.wait(15);

            //Enter the value Rep Amount
            //RepAmount.SendKeys(ExcelLib.ReadData(2, "RepAmount"));
            //Driver.wait(15);

            //Clear Rep Start Date and send value
            // RepStartDate.Click();
            //RepStartDate.Clear();
            //RepStartDate.SendKeys(ExcelLib.ReadData(2, "RepStartDate"));


            //Click Add Expense
            //AddExpense.Click();
            //((IJavaScriptExecutor)Driver.driver).ExecuteScript("arguments[0].click();", AddExpense);
            //Driver.wait(15);

            //Enter the value in Exp Amount
            //ExpAmount.SendKeys(ExcelLib.ReadData(2, "ExpAmount"));
            //Driver.wait(15);

            //Enter the value in Exp Description
            //ExpDescription.SendKeys(ExcelLib.ReadData(2, "ExpDescription"));
            //Driver.wait(15);

            //Click Exp Date
            //ExpDate.Clear();
            // ExpDate.SendKeys(ExcelLib.ReadData(2, "ExpDate"));
            //Driver.wait(15);

            //clcik next button
            NextFin.Click();
            Driver.wait(15);

            string ExpectedValue = "Tenant Details";
            string ActualValue = Global.Driver.driver.FindElement(By.XPath("//*[@id='tenantSection']/h2")).Text;

            //Assert.AreEqual(ExpectedValue, ActualValue);
            if (ExpectedValue == ActualValue)

                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Pass, "Test Passed, Add Finance Details successfull");

            else
                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Test Failed, Add Finance Details Unsuccessfull");

        }


        public void AddTenantDetails()

        {
            Driver.wait(15);

            // Populating the data from Excel
            ExcelLib.PopulateInCollection(Base.ExcelPath, "TenantDetailsPage");

            //Enter the value in Tenant Email
            TenantEmail.SendKeys(ExcelLib.ReadData(2, "TenantEmail"));

            //Enter the value in Ten First Name
            TenFirstName.SendKeys(ExcelLib.ReadData(2, "TenFirstName"));

            //Enter the value in Ten Last Name
            TenLastName.SendKeys(ExcelLib.ReadData(2, "TenLastName"));

            //Clear Ten Start Date and send value
            TenStartDate.Clear();
            TenStartDate.SendKeys(ExcelLib.ReadData(2, "TenStartDate"));

            //Clear Ten End Date and send value
            TenEndDate.Clear();
            TenEndDate.SendKeys(ExcelLib.ReadData(2, "TenEndDate"));

            //Enter value in Ten Rent Amount
            TenRentAmount.SendKeys(ExcelLib.ReadData(2, "TenRentAmount"));

            //Clear Ten Payment Start Date and send value
            TenPaymentStartDate.Clear();
            TenPaymentStartDate.SendKeys(ExcelLib.ReadData(2, "TenPaymentStartDate"));

            //Click Add New Liability
            ((IJavaScriptExecutor)Driver.driver).ExecuteScript("arguments[0].click();", AddNewLiability);
            //AddNewLiability.Click();
            Driver.wait(15);

            //Enter the value in Liability Amount
            LiabilityAmount.SendKeys(ExcelLib.ReadData(2, "LiabilityAmount"));

            //Click Save Button
            TenSave.Click();
            Driver.wait(5);

            string ExpectedValue = "My Properties";
            string ActualValue = Global.Driver.driver.FindElement(By.XPath("//*[@id='main-content']/div/div[1]/div/div[1]/div[1]/h2[1]")).Text;

            //Assert.AreEqual(ExpectedValue, ActualValue);
            if (ExpectedValue == ActualValue)

                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Pass, "Test Passed, Add Tenant Details successfull");

            else
                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Test Failed, Add Tenant Details Unsuccessfull");

        }

    }
}


 
 