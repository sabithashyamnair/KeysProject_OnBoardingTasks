﻿using Keys_Onboarding.Global;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Keys_Onboarding.Test
{
    class Sprint 
    {
      [TestFixture]
      [Category("Sprint1")]
       class Tenant : Base
        {

            [Test]
            public void TC1_AddNewProperty()
            {
                // Creates a toggle for the given test, adds all log events under it    
                test = extent.StartTest("Add new Property");

                // Create an class and object to call the method
                Owner_Properties obj = new Owner_Properties();
                obj.AddNewProperty();

            }


            [Test]
            public void TC2_SearchAProperty()
            {
                // Creates a toggle for the given test, adds all log events under it    
                test = extent.StartTest("Search for a Property");

                // Create an class and object to call the method
                Owner_Properties obj = new Owner_Properties();
                obj.SearchAProperty();

            }

            [Test]
            public void TC3_ListARental()
            {
                // Creates a toggle for the given test, adds all log events under it    
                test = extent.StartTest("List a Rental for a property");

                // Create an class and object to call the method
                Owner_Properties obj = new Owner_Properties();
                obj.ListRentalProperty();

            }

            [Test]
            public void TC4_DeleteAProperty()
            {
                // Creates a toggle for the given test, adds all log events under it    
                test = extent.StartTest("Delete a property");

                // Create an class and object to call the method
                Owner_Properties obj = new Owner_Properties();
                obj.DeleteAProperty();

            }



        }
    }
}
